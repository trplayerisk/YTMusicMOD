package com.ytmusic;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** googlevideo'yu 1 MB'lik Range parcalariyla okur (tek parca istek bazen 403/throttle yer). */
final class RangeStream extends InputStream {
    private static final int CHUNK = 1 << 20;
    private final String url;
    private long pos = 0, total = -1;
    private byte[] buf = new byte[0];
    private int bi = 0;

    RangeStream(String url) { this.url = url; }

    private boolean fill() throws IOException {
        if (bi < buf.length) return true;
        if (total >= 0 && pos >= total) return false;
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setRequestProperty("User-Agent", YouTubeService.UA);
        c.setRequestProperty("Range", "bytes=" + pos + "-" + (pos + CHUNK - 1));
        int code = c.getResponseCode();
        if (code != 200 && code != 206) throw new IOException("HTTP " + code);
        String cr = c.getHeaderField("Content-Range");
        if (cr != null && cr.contains("/")) {
            try { total = Long.parseLong(cr.substring(cr.indexOf('/') + 1).trim()); } catch (Exception ignored) {}
        }
        buf = c.getInputStream().readAllBytes();
        bi = 0;
        pos += buf.length;
        if (code == 200) total = pos;
        return buf.length > 0;
    }

    @Override public int read() throws IOException {
        if (!fill()) return -1;
        return buf[bi++] & 0xFF;
    }

    @Override public int read(byte[] b, int o, int l) throws IOException {
        if (!fill()) return -1;
        int n = Math.min(l, buf.length - bi);
        System.arraycopy(buf, bi, b, o, n);
        bi += n;
        return n;
    }
}
