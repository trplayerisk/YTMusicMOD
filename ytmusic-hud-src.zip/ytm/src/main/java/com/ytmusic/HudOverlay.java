package com.ytmusic;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

public final class HudOverlay {
    private static float anim = 0f;
    private static final int W = 160, H = 40;

    public static void render(DrawContext ctx, RenderTickCounter tc) {
        Track t = AudioPlayer.current;
        float target = (t != null && Config.hudVisible) ? 1f : 0f;
        anim += (target - anim) * 0.12f;           // yumusak kayma
        if (anim < 0.01f || t == null) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        int x = (int) (Config.hudX * (sw - W)) - (int) ((1f - anim) * (W + 12));
        int y = (int) (Config.hudY * (sh - H));
        long now = System.currentTimeMillis();

        ctx.fill(x, y, x + W, y + H, 0xB0101018);
        ctx.fill(x, y, x + 2, y + H, 0xFFFF3B3B);

        // Kayan baslik (marquee)
        int tw = tr.getWidth(t.title());
        int areaL = x + 6, areaR = x + W - 24;
        ctx.enableScissor(areaL, y + 3, areaR, y + 14);
        if (tw <= areaR - areaL) {
            ctx.drawText(tr, t.title(), areaL, y + 4, 0xFFFFFFFF, true);
        } else {
            int off = (int) ((now / 30) % (tw + 30));
            ctx.drawText(tr, t.title(), areaL - off, y + 4, 0xFFFFFFFF, true);
            ctx.drawText(tr, t.title(), areaL - off + tw + 30, y + 4, 0xFFFFFFFF, true);
        }
        ctx.disableScissor();

        String sub = AudioPlayer.status.isEmpty() ? t.artist() : AudioPlayer.status;
        ctx.drawText(tr, tr.trimToWidth(sub, W - 30), x + 6, y + 15, 0xFFAAAAAA, false);

        // Hareketli ekolayzer cubuklari
        boolean moving = AudioPlayer.status.isEmpty() && !AudioPlayer.paused;
        for (int i = 0; i < 4; i++) {
            int bh = moving ? 3 + (int) ((Math.sin(now / 140.0 + i * 1.7) + 1) * 4) : 2;
            int bx = x + W - 20 + i * 4;
            ctx.fill(bx, y + 14 - bh, bx + 3, y + 14, 0xFFFF3B3B);
        }

        // Saniye gostergesi + ilerleme cubugu
        long cur = (long) AudioPlayer.seconds();
        String time = fmt(cur) + " / " + fmt(t.duration());
        ctx.drawText(tr, time, x + 6, y + 26, 0xFFFFFFFF, false);
        int bx1 = x + 6 + tr.getWidth(time) + 6, bx2 = x + W - 6;
        if (bx2 > bx1) {
            ctx.fill(bx1, y + 29, bx2, y + 31, 0xFF444444);
            float p = t.duration() > 0 ? Math.min(1f, cur / (float) t.duration()) : 0f;
            ctx.fill(bx1, y + 29, bx1 + (int) ((bx2 - bx1) * p), y + 31, 0xFFFF3B3B);
        }
    }

    static String fmt(long s) { return (s / 60) + ":" + String.format("%02d", s % 60); }
}
