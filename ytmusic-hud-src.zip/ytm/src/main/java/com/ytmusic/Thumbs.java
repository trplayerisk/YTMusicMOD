package com.ytmusic;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import org.lwjgl.stb.STBImage;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/** Kucuk resimleri indirir (JPEG/PNG), STB ile cozer, dokuya cevirir. Hata olursa kutu bos kalir. */
public final class Thumbs {
    public record Thumb(Identifier id, int w, int h) {}

    private static final Map<String, Thumb> cache = new ConcurrentHashMap<>();
    private static final Set<String> loading = ConcurrentHashMap.newKeySet();

    /** Hazirsa doku, degilse null (arka planda yuklemeyi baslatir). */
    public static Thumb get(String url) {
        if (url == null) return null;
        Thumb t = cache.get(url);
        if (t != null) return t;
        if (loading.add(url)) {
            Thread th = new Thread(() -> load(url), "ytmusic-thumb");
            th.setDaemon(true);
            th.start();
        }
        return null;
    }

    private static void load(String url) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(10000);
            c.setReadTimeout(10000);
            c.setRequestProperty("User-Agent", YouTubeService.UA);
            byte[] data = c.getInputStream().readAllBytes();

            ByteBuffer raw = MemoryUtil.memAlloc(data.length);
            raw.put(data).flip();
            NativeImage img;
            int W, H;
            try (MemoryStack st = MemoryStack.stackPush()) {
                IntBuffer w = st.mallocInt(1), h = st.mallocInt(1), comp = st.mallocInt(1);
                ByteBuffer px = STBImage.stbi_load_from_memory(raw, w, h, comp, 4);
                if (px == null) throw new RuntimeException("resim cozulemedi");
                W = w.get(0);
                H = h.get(0);
                img = new NativeImage(W, H, false);
                for (int y = 0; y < H; y++) {
                    for (int x = 0; x < W; x++) {
                        int i = (y * W + x) * 4;
                        int r = px.get(i) & 0xFF, g = px.get(i + 1) & 0xFF, b = px.get(i + 2) & 0xFF, a = px.get(i + 3) & 0xFF;
                        img.setColorArgb(x, y, (a << 24) | (r << 16) | (g << 8) | b);
                    }
                }
                STBImage.stbi_image_free(px);
            } finally {
                MemoryUtil.memFree(raw);
            }
            final int fw = W, fh = H;
            MinecraftClient mc = MinecraftClient.getInstance();
            mc.execute(() -> {
                Identifier id = Identifier.of("ytmusic", "thumb/" + Integer.toHexString(url.hashCode()));
                mc.getTextureManager().registerTexture(id, new NativeImageBackedTexture("ytmusic_thumb", img));
                cache.put(url, new Thumb(id, fw, fh));
            });
        } catch (Throwable ignored) {
        }
    }
}
