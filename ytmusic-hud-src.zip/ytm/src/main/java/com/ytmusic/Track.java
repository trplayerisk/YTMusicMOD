package com.ytmusic;

public record Track(String title, String artist, String url, long duration, String thumb) {}
