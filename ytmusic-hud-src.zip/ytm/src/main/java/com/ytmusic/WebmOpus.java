package com.ytmusic;

import java.io.DataInputStream;
import java.io.IOException;
import java.util.Arrays;

/** Minimal WebM okuyucu: Opus paketlerini (SimpleBlock/Block) sirayla verir. */
final class WebmOpus {
    private static final long SEGMENT = 0x18538067L, CLUSTER = 0x1F43B675L, BLOCKGROUP = 0xA0L;
    private static final long SIMPLEBLOCK = 0xA3L, BLOCK = 0xA1L;

    /** Sonraki Opus paketi, dosya bittiyse null. */
    static byte[] next(DataInputStream in) throws IOException {
        while (true) {
            long id = readId(in);
            if (id < 0) return null;
            long size = readSize(in);
            if (id == SEGMENT || id == CLUSTER || id == BLOCKGROUP) continue; // icine gir
            if (id == SIMPLEBLOCK || id == BLOCK) {
                byte[] b = in.readNBytes((int) size);
                if (b.length < 5) return null;
                int len = Integer.numberOfLeadingZeros(b[0] & 0xFF) - 24 + 1; // track no vint
                return Arrays.copyOfRange(b, len + 3, b.length);
            }
            if (size < 0) continue;
            in.skipNBytes(size);
        }
    }

    private static long readId(DataInputStream in) throws IOException {
        int b = in.read();
        if (b < 0) return -1;
        int len = Integer.numberOfLeadingZeros(b) - 24 + 1;
        long v = b;
        for (int i = 1; i < len; i++) v = (v << 8) | (in.readUnsignedByte());
        return v;
    }

    private static long readSize(DataInputStream in) throws IOException {
        int b = in.readUnsignedByte();
        int len = Integer.numberOfLeadingZeros(b) - 24 + 1;
        long v = b & (0xFF >> len);
        boolean allOnes = v == (0xFF >> len);
        for (int i = 1; i < len; i++) {
            int x = in.readUnsignedByte();
            if (x != 0xFF) allOnes = false;
            v = (v << 8) | x;
        }
        return allOnes ? -1 : v;
    }
}
