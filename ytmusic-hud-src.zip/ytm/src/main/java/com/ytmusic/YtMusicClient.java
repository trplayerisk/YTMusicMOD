package com.ytmusic;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;

import java.util.List;

public class YtMusicClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        Config.load();
        HudElementRegistry.addLast(Identifier.of("ytmusic", "hud"), HudOverlay::render);

        // Mobilde Mod Menu yerine sohbetten: /ytm  ->  menu,  /ytm <sarki>  ->  ilk sonucu cal
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, access) ->
            dispatcher.register(ClientCommandManager.literal("ytm")
                .executes(c -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.execute(() -> mc.setScreen(new MusicScreen(null)));
                    return 1;
                })
                .then(ClientCommandManager.argument("sarki", StringArgumentType.greedyString())
                    .executes(c -> {
                        String q = StringArgumentType.getString(c, "sarki");
                        AudioPlayer.status = "Araniyor...";
                        new Thread(() -> {
                            try {
                                List<Track> r = YouTubeService.search(q);
                                if (!r.isEmpty()) AudioPlayer.play(r.get(0));
                                else AudioPlayer.status = "Sonuc yok";
                            } catch (Throwable e) {
                                AudioPlayer.status = "Hata: " + e.getMessage();
                            }
                        }, "ytmusic-cmd").start();
                        return 1;
                    }))));
    }
}
