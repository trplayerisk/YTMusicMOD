package com.ytmusic;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class MusicScreen extends Screen {
    private static final int ROW_H = 40, LIST_TOP = 44, TH_W = 64, TH_H = 36;

    private final Screen parent;
    private TextFieldWidget field;
    private final List<ClickableWidget> rowBtns = new ArrayList<>();
    private volatile List<Track> results = new ArrayList<>();
    private volatile String msg = "";
    private int page = 0, rows = 2, pw, left;

    public MusicScreen(Screen parent) {
        super(Text.literal("YT Music"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        pw = Math.min(300, width - 10);
        left = width / 2 - pw / 2;
        int base = height - 50;
        rows = Math.max(1, (base - LIST_TOP - 4) / ROW_H);

        field = new TextFieldWidget(textRenderer, left, 18, pw - 130, 20, Text.literal("Ara"));
        field.setMaxLength(100);
        field.setPlaceholder(Text.literal("Sarki adi..."));
        addDrawableChild(field);
        addDrawableChild(ButtonWidget.builder(Text.literal("Ara"), b -> doSearch())
                .dimensions(left + pw - 126, 18, 44, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("<"), b -> changePage(-1))
                .dimensions(left + pw - 78, 18, 36, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> changePage(1))
                .dimensions(left + pw - 38, 18, 36, 20).build());

        int bw = (pw - 6) / 4;
        ButtonWidget pause = ButtonWidget.builder(Text.literal("Duraklat"), b -> {
            AudioPlayer.togglePause();
            b.setMessage(Text.literal(AudioPlayer.paused ? "Devam" : "Duraklat"));
        }).dimensions(left, base, bw, 20).build();
        addDrawableChild(pause);
        addDrawableChild(ButtonWidget.builder(Text.literal("Durdur"), b -> AudioPlayer.stop())
                .dimensions(left + (bw + 2), base, bw, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("HUD: " + (Config.hudVisible ? "Acik" : "Kapali")), b -> {
            Config.hudVisible = !Config.hudVisible;
            b.setMessage(Text.literal("HUD: " + (Config.hudVisible ? "Acik" : "Kapali")));
        }).dimensions(left + 2 * (bw + 2), base, bw, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Bitti"), b -> close())
                .dimensions(left + 3 * (bw + 2), base, bw, 20).build());

        int sw = (pw - 4) / 3;
        addDrawableChild(new Sl(left, base + 22, sw, "Ses", Config.volume, v -> Config.volume = v.floatValue()));
        addDrawableChild(new Sl(left + sw + 2, base + 22, sw, "HUD X", Config.hudX, v -> Config.hudX = v.floatValue()));
        addDrawableChild(new Sl(left + 2 * (sw + 2), base + 22, sw, "HUD Y", Config.hudY, v -> Config.hudY = v.floatValue()));

        rebuildRows();
    }

    private void changePage(int d) {
        int max = Math.max(0, (results.size() - 1) / rows);
        page = Math.max(0, Math.min(max, page + d));
        rebuildRows();
    }

    private void doSearch() {
        String q = field.getText().trim();
        if (q.isEmpty()) return;
        msg = "Araniyor...";
        new Thread(() -> {
            try {
                results = YouTubeService.search(q);
                page = 0;
                msg = results.isEmpty() ? "Sonuc yok" : "";
            } catch (Throwable e) {
                msg = "Hata: " + e.getClass().getSimpleName() + " " + e.getMessage();
            }
            MinecraftClient.getInstance().execute(this::rebuildRows);
        }, "ytmusic-search").start();
    }

    /** Her satir icin gorunmez-metinli bir dugme (tiklama + hover icin); icerigi render'da ustune ciziyoruz. */
    private void rebuildRows() {
        for (ClickableWidget w : rowBtns) remove(w);
        rowBtns.clear();
        for (int i = 0; i < rows; i++) {
            int idx = page * rows + i;
            if (idx >= results.size()) break;
            Track t = results.get(idx);
            ButtonWidget b = ButtonWidget.builder(Text.empty(), x -> AudioPlayer.play(t))
                    .dimensions(left, LIST_TOP + i * ROW_H, pw, ROW_H - 2).build();
            rowBtns.add(b);
            addDrawableChild(b);
        }
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);

        for (int i = 0; i < rows; i++) {
            int idx = page * rows + i;
            if (idx >= results.size()) break;
            Track t = results.get(idx);
            int y = LIST_TOP + i * ROW_H;

            ctx.fill(left + 2, y + 2, left + 2 + TH_W, y + 2 + TH_H, 0xFF222222);
            Thumbs.Thumb th = Thumbs.get(t.thumb());
            if (th != null) {
                ctx.drawTexture(RenderPipelines.GUI_TEXTURED, th.id(), left + 2, y + 2, 0f, 0f,
                        TH_W, TH_H, th.w(), th.h(), th.w(), th.h());
            }
            int tx = left + TH_W + 8, tw = pw - TH_W - 12;
            ctx.drawText(textRenderer, textRenderer.trimToWidth(t.title(), tw), tx, y + 6, 0xFFFFFFFF, true);
            String sub = t.artist() + (t.duration() > 0 ? "  -  " + HudOverlay.fmt(t.duration()) : "");
            ctx.drawText(textRenderer, textRenderer.trimToWidth(sub, tw), tx, y + 20, 0xFFAAAAAA, false);
        }

        String line = !msg.isEmpty() ? msg : AudioPlayer.status;
        if (line.isEmpty() && !results.isEmpty()) {
            line = (page + 1) + " / " + (Math.max(0, (results.size() - 1) / rows) + 1);
        }
        if (!line.isEmpty()) {
            ctx.drawText(textRenderer, line, width / 2 - textRenderer.getWidth(line) / 2, 6, 0xFFFFFF55, true);
        }
    }

    @Override
    public void close() {
        Config.save();
        MinecraftClient.getInstance().setScreen(parent);
    }

    private static final class Sl extends SliderWidget {
        private final String label;
        private final Consumer<Double> setter;

        Sl(int x, int y, int w, String label, double v, Consumer<Double> setter) {
            super(x, y, w, 20, Text.literal(label), v);
            this.label = label;
            this.setter = setter;
            updateMessage();
        }

        @Override protected void updateMessage() {
            setMessage(Text.literal(label + ": " + (int) (value * 100) + "%"));
        }

        @Override protected void applyValue() { setter.accept(value); }
    }
}
