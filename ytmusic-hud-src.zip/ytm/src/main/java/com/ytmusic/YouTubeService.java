package com.ytmusic;

import org.schabi.newpipe.extractor.InfoItem;
import org.schabi.newpipe.extractor.MediaFormat;
import org.schabi.newpipe.extractor.NewPipe;
import org.schabi.newpipe.extractor.ServiceList;
import org.schabi.newpipe.extractor.downloader.Downloader;
import org.schabi.newpipe.extractor.downloader.Request;
import org.schabi.newpipe.extractor.downloader.Response;
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException;
import org.schabi.newpipe.extractor.localization.Localization;
import org.schabi.newpipe.extractor.search.SearchExtractor;
import org.schabi.newpipe.extractor.stream.AudioStream;
import org.schabi.newpipe.extractor.stream.DeliveryMethod;
import org.schabi.newpipe.extractor.stream.StreamInfo;
import org.schabi.newpipe.extractor.stream.StreamInfoItem;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class YouTubeService {
    static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0";
    private static boolean inited;

    private static synchronized void init() {
        if (!inited) {
            NewPipe.init(new Dl(), new Localization("tr", "TR"));
            inited = true;
        }
    }

    public static List<Track> search(String q) throws Exception {
        init();
        List<Track> out = new ArrayList<>();
        for (String filter : new String[]{"music_songs", "videos"}) {
            SearchExtractor ex = ServiceList.YouTube.getSearchExtractor(q, List.of(filter), "");
            ex.fetchPage();
            for (InfoItem i : ex.getInitialPage().getItems()) {
                if (i instanceof StreamInfoItem s) {
                    out.add(new Track(s.getName(), s.getUploaderName(), s.getUrl(), s.getDuration(), pickThumb(s)));
                }
            }
            if (!out.isEmpty()) break;
        }
        return out;
    }

    private static String pickThumb(StreamInfoItem s) {
        var list = s.getThumbnails();
        if (list == null || list.isEmpty()) return null;
        for (var img : list) if (img.getWidth() >= 120) return img.getUrl();
        return list.get(list.size() - 1).getUrl();
    }

    /** Opus (webm) ses akisinin dogrudan URL'si. */
    public static String audioUrl(String videoUrl) throws Exception {
        init();
        StreamInfo info = StreamInfo.getInfo(ServiceList.YouTube, videoUrl);
        AudioStream best = null;
        for (AudioStream a : info.getAudioStreams()) {
            if (a.getDeliveryMethod() != DeliveryMethod.PROGRESSIVE_HTTP) continue;
            if (a.getFormat() != MediaFormat.WEBMA_OPUS) continue;
            if (best == null || a.getAverageBitrate() > best.getAverageBitrate()) best = a;
        }
        if (best == null) throw new IOException("Opus ses akisi bulunamadi");
        return best.getContent();
    }

    static final class Dl extends Downloader {
        @Override
        public Response execute(Request r) throws IOException, ReCaptchaException {
            HttpURLConnection c = (HttpURLConnection) new URL(r.url()).openConnection();
            c.setRequestMethod(r.httpMethod());
            c.setConnectTimeout(15000);
            c.setReadTimeout(20000);
            c.setRequestProperty("User-Agent", UA);
            for (Map.Entry<String, List<String>> e : r.headers().entrySet()) {
                c.setRequestProperty(e.getKey(), String.join(", ", e.getValue()));
            }
            byte[] d = r.dataToSend();
            if (d != null) {
                c.setDoOutput(true);
                c.getOutputStream().write(d);
            }
            int code = c.getResponseCode();
            if (code == 429) throw new ReCaptchaException("429", r.url());
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String body = in == null ? "" : new String(in.readAllBytes(), StandardCharsets.UTF_8);
            Map<String, List<String>> h = new HashMap<>();
            c.getHeaderFields().forEach((k, v) -> { if (k != null) h.put(k, v); });
            return new Response(code, c.getResponseMessage(), h, body, c.getURL().toString());
        }
    }
}
