# YT Music HUD (Fabric 1.21.11)

## Kurulum
1. https://fabricmc.net/develop adresinden 1.21.11 icin bos bir mod sablonu indir (mod id: ytmusic, package: com.ytmusic).
2. Sablondaki src/ klasorunu bu zip'teki src/ ile degistir (fabric.mod.json dahil).
3. build.gradle'a ekle:

repositories {
    maven { url "https://jitpack.io" }
    maven { url "https://maven.terraformersmc.com/" }
}
dependencies {
    modImplementation "com.terraformersmc:modmenu:<1.21.11 surumu>"

    // Gomulu (JiJ) kutuphaneler - surumleri guncelle
    implementation include("com.github.TeamNewPipe:NewPipeExtractor:v0.24.8")
    implementation include("com.github.TeamNewPipe:nanojson:1d9e1aea9049fc9f85e68b43ba39fe7be1c1f751")
    implementation include("org.jsoup:jsoup:1.17.2")
    implementation include("org.mozilla:rhino:1.7.15")
    implementation include("com.google.protobuf:protobuf-javalite:3.25.5")
    implementation include("com.google.code.findbugs:jsr305:3.0.2")
    implementation include("io.github.jaredmdobson:concentus:1.0.2")
}

4. ./gradlew build  ->  build/libs/*.jar

## Kullanim
- Mod Menu > YT Music HUD > ayar ikonu, veya oyunda /ytm, veya /ytm <sarki adi>
